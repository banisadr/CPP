#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGui/QApplication>
#include <QMessageBox>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()//When Logon Button Pressed
{

    QString user = ui->lineEdit->text();
    QString pwd_attempt = ui->lineEdit_2->text();
    QString pwd_actual;
    if(true) //replace with check if user exists: user_exsists(user)
        QString pwd_actual = "password"; //Look up user & pull pwd     <-----NOT WORKING

    if(true && pwd_actual == pwd_attempt) //replace "true" with check if user exists: user_exsists(user)
    {
        curr_user = user;
        ui->stackedWidget->setCurrentIndex(1);
    }
    else //case if user doesn't exist or pwd is wrong
    {
        QMessageBox msgBox;
        msgBox.setText("Username/Password Invalid");
        msgBox.exec();
        ui->lineEdit->setPlaceholderText("Invalid Username or Password");
        ui->lineEdit_2->setPlaceholderText("Invalid Username or Password");
    }
}

void MainWindow::on_stackedWidget_currentChanged(int arg1) //When Profile Widget Becomes Active
{
    ui->username->setText("Get Username");
    ui->phone->setText("Get Phone #");
    ui->position->setText("Get Position");
    ui->email->setText("Get Email");
    ui->location->setText("Get Location");
    //ui->picture->setPicture(); <----How to set arguments?
}

void MainWindow::on_logout_clicked()//Logout Clicked
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_return_profile_clicked()// Return From Search
{
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_pushButton_3_clicked() //Search Dialog Used
{
    ui->stackedWidget->setCurrentIndex(2);
    QString search = ui->search->text();
    //Need to Impliment search and display results somehow
}

void MainWindow::on_pushButton_4_clicked()//Click Upload Picture
{
    ui->photo_location->setText(QFileDialog::getOpenFileName(this, tr("Open File"),
                                                             "/home",
                                                             tr("Images (*.png *.xpm *.jpg)")));
}

void MainWindow::on_pushButton_2_clicked() //Click Create Profile
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_save_clicked() //Click Save Profile Edits
{
    QString pwd = ui ->pwd_edit->text();
    QString pwd_check = ui->pwd_edit_check->text();

    if(pwd == pwd_check)
    {
        QString name = ui->name_edit->text();
        QString phone = ui->phone_edit->text();
        QString position = ui->position_edit->text();
        QString email = ui->email_edit->text();
        QString location = ui->location_edit->text();
        //***NEED TO UPDATE DIRECTORY WITH NEW INFORMATION***
        ui->stackedWidget->setCurrentIndex(1);
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("Passwords Do Not Match");
        msgBox.exec();
    }

}

void MainWindow::on_edit_clicked() //Clicked Edit From Profile
{
    ui->stackedWidget->setCurrentIndex(3);
    ui->name_edit->setText("Get User Name");
    ui->phone_edit->setText("Get User Phone");
    ui->position_edit->setText("Get User Position");
    ui->email_edit->setText("Get User Email");
    ui->location_edit->setText("Get User Location");
}
